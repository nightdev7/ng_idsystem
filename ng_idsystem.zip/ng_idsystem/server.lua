ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
local label = [[

Night Company - Id system

]]


Citizen.CreateThread(function()

    print(label)

end)

ESX.RegisterServerCallback('KxSystem:server:GetActiveCops', function(source, cb)
    local retval = 0
    
    for k, v in pairs(ESX.GetPlayers()) do
        local Player = ESX.GetPlayers(v)
        local _source = source
        local xPlayer = ESX.GetPlayerFromId(_source)
        
        if Player ~= nil then
            if xPlayer.job.name == "police" then
                retval = retval + 1
            end
        end
    end

    cb(retval)
end)

ESX.RegisterServerCallback('KxSystem:server:GetConfig', function(source, cb)
    cb(Config.IllegalActions)
end)

RegisterServerEvent('KxSystem:server:SetActivityBusy')
AddEventHandler('KxSystem:server:SetActivityBusy', function(activity, bool)
    Config.IllegalActions[activity].busy = bool
    TriggerClientEvent('KxSystem:client:SetActivityBusy', -1, activity, bool)
end)